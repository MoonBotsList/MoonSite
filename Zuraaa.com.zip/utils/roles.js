module.exports = Object.freeze({
  admin: 1,
  approver: 2
})
