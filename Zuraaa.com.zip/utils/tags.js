module.exports = {
  anime: 'Anime',
  dashboard: 'Dashboard',
  diversao: 'Diversão',
  utilidades: 'Utilidades',
  social: 'Social',
  jogos: 'Jogos',
  musica: 'Música',
  moderacao: 'Moderação',
  economia: 'Economia',
  nsfw: 'NSFW',
  outros: 'Outros'
}
