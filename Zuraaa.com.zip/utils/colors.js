module.exports = [
  'red',
  'darkorange',
  'orange',
  'yellow',
  'yellowgreen',
  'green',
  'seagreen',
  'dodgerblue',
  'blue',
  'indigo',
  'purple',
  'darkmagenta',
  'darkviolet',
  'violet',
  'pink'
]
