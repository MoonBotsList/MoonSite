window.onSubmit = function onSubmit () {
  $('#votef').submit()
}
