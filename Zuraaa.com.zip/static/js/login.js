window.onSubmit = function onSubmit () {
  document.getElementById('login').submit()
}
